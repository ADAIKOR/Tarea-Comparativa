// deno/index.ts
const start = performance.now();

// Leer archivo CSV - buscar en la carpeta data (carpeta hermana)
const csvPath = '../data/estudiantes.csv';
console.log('📁 Buscando CSV en:', csvPath);

let csvContent;
try {
  csvContent = await Deno.readTextFile(csvPath);
} catch (error) {
  console.error('❌ Error al leer CSV:', error.message);
  Deno.exit(1);
}

const lines = csvContent.trim().split('\n');

// Saltar header
const header = lines[0];
const dataLines = lines.slice(1);

let aprobados = 0;
let reprobados = 0;
const resultados: Array<{
  nombre: string;
  nota1: number;
  nota2: number;
  nota3: number;
  promedio: number;
  estado: string;
}> = [];

// Procesar cada línea
for (const line of dataLines) {
  const [nombre, nota1Str, nota2Str, nota3Str] = line.split(',');
  
  const nota1 = parseFloat(nota1Str);
  const nota2 = parseFloat(nota2Str);
  const nota3 = parseFloat(nota3Str);
  
  const promedio = parseFloat(((nota1 + nota2 + nota3) / 3).toFixed(2));
  const estado = promedio >= 7.0 ? 'Aprobado' : 'Reprobado';
  
  if (estado === 'Aprobado') {
    aprobados++;
  } else {
    reprobados++;
  }
  
  resultados.push({
    nombre,
    nota1,
    nota2,
    nota3,
    promedio,
    estado
  });
}

const end = performance.now();
const tiempoMs = parseFloat((end - start).toFixed(2));

// Generar JSON de salida
const output = {
  runtime: 'deno',
  tiempoMs,
  totalEstudiantes: resultados.length,
  aprobados,
  reprobados,
  resultados
};

// Escribir archivo
const outputDir = '../output';
try {
  await Deno.stat(outputDir);
} catch {
  await Deno.mkdir(outputDir, { recursive: true });
}

const outputPath = '../output/resultado-deno.json';
await Deno.writeTextFile(outputPath, JSON.stringify(output, null, 2));

// Imprimir en consola
console.log('\n--- 📊 RESULTADOS DENO ---');
console.log(`⏱️  Tiempo de ejecución: ${tiempoMs} ms`);
console.log(`👥 Total de estudiantes: ${resultados.length}`);
console.log(`✅ Aprobados: ${aprobados}`);
console.log(`❌ Reprobados: ${reprobados}`);
console.log(`📁 Archivo guardado: ${outputPath}\n`);
