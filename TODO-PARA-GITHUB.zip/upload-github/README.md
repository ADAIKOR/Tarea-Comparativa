# 🚀 Comparativa de Runtimes: Node.js vs Deno vs Bun

**Instituto Superior Tecnológico Cordillera**
Carrera de Desarrollo de Software · Frontend Moderno 2026

## 📌 Objetivo

Comparar las diferencias prácticas entre Node.js, Deno y Bun ejecutando el mismo script en los tres runtimes.

## 📊 Resultados

| Criterio | Node.js | Deno | Bun |
|----------|---------|------|-----|
| **Tiempo (ms)** | **7.23** | **12.45** | **4.87** |
| Líneas de código | 84 | 90 | 83 |
| package.json | Sí | No | Sí |
| TypeScript nativo | No | Sí | Sí |
| Permisos explícitos | No | Sí | No |
| Dificultad (1-10) | 4 | 6 | 5 |

## 🎯 Conclusiones

- **Bun fue 33% más rápido que Node.js**
- **Node.js es el más fácil de configurar**
- **Deno es el más seguro con permisos explícitos**

## 📄 Documentos

✅ INFORME_COMPLETO_JOE_VALDEZ.docx
✅ INFORME_FINAL_JOE_VALDEZ.docx
✅ DOCUMENTO_EJECUTIVO_JOE_VALDEZ.docx
✅ README_JOE_VALDEZ.docx

---

**Estudiante:** JOE Valdez
**Institución:** Instituto Superior Tecnológico Cordillera
**Fecha:** 18 de Marzo, 2026
