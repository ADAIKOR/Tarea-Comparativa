// node/index.js
const fs = require('fs');
const path = require('path');

const start = performance.now();

// Leer archivo CSV - buscar en la carpeta data (carpeta hermana)
const csvPath = path.join(__dirname, '../data/estudiantes.csv');
console.log('📁 Buscando CSV en:', csvPath);

let csvContent;
try {
  csvContent = fs.readFileSync(csvPath, 'utf-8');
} catch (error) {
  console.error('❌ Error al leer CSV:', error.message);
  process.exit(1);
}

const lines = csvContent.trim().split('\n');

// Saltar header
const header = lines[0];
const dataLines = lines.slice(1);

let aprobados = 0;
let reprobados = 0;
const resultados = [];

// Procesar cada línea
for (const line of dataLines) {
  const [nombre, nota1Str, nota2Str, nota3Str] = line.split(',');
  
  const nota1 = parseFloat(nota1Str);
  const nota2 = parseFloat(nota2Str);
  const nota3 = parseFloat(nota3Str);
  
  const promedio = parseFloat(((nota1 + nota2 + nota3) / 3).toFixed(2));
  const estado = promedio >= 7.0 ? 'Aprobado' : 'Reprobado';
  
  if (estado === 'Aprobado') {
    aprobados++;
  } else {
    reprobados++;
  }
  
  resultados.push({
    nombre,
    nota1,
    nota2,
    nota3,
    promedio,
    estado
  });
}

const end = performance.now();
const tiempoMs = parseFloat((end - start).toFixed(2));

// Generar JSON de salida
const output = {
  runtime: 'node',
  tiempoMs,
  totalEstudiantes: resultados.length,
  aprobados,
  reprobados,
  resultados
};

// Escribir archivo
const outputDir = path.join(__dirname, '../output');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

const outputPath = path.join(outputDir, 'resultado-node.json');
fs.writeFileSync(outputPath, JSON.stringify(output, null, 2));

// Imprimir en consola
console.log('\n--- 📊 RESULTADOS NODE.JS ---');
console.log(`⏱️  Tiempo de ejecución: ${tiempoMs} ms`);
console.log(`👥 Total de estudiantes: ${resultados.length}`);
console.log(`✅ Aprobados: ${aprobados}`);
console.log(`❌ Reprobados: ${reprobados}`);
console.log(`📁 Archivo guardado: ${outputPath}\n`);
